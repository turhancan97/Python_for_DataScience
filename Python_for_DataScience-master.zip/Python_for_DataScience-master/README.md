# Python_Egitim
Temel Python Kodları
